
import React from 'react';
import { DEVELOPER_PROFILE, IconSocialGithub, IconSocialLinkedin, IconMail } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 py-8 text-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center space-x-6 mb-4">
          <a href={DEVELOPER_PROFILE.contact.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
            <IconSocialGithub className="w-6 h-6" />
          </a>
          <a href={DEVELOPER_PROFILE.contact.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
            <IconSocialLinkedin className="w-6 h-6" />
          </a>
          <a href={`mailto:${DEVELOPER_PROFILE.contact.email}`} aria-label="Email" className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
            <IconMail className="w-6 h-6" />
          </a>
        </div>
        <p className="text-sm">
          &copy; {new Date().getFullYear()} {DEVELOPER_PROFILE.name}. All rights reserved.
        </p>
        <p className="text-xs mt-1">
          Built with React, Tailwind CSS, and ❤️. Chatbot powered by Gemini.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
    