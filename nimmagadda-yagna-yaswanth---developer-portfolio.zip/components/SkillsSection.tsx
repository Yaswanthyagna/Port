
import React from 'react';
import Section from './common/Section';
import { SkillCategory } from '../types';

interface SkillsSectionProps {
  id: string;
  skills: SkillCategory[];
}

const SkillsSection: React.FC<SkillsSectionProps> = ({ id, skills }) => {
  return (
    <Section id={id} title="My Skills" className="bg-white dark:bg-slate-800">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {skills.map((category) => (
          <div key={category.name} className="bg-slate-50 dark:bg-slate-700 p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-sky-600 dark:text-sky-400">{category.name}</h3>
            <ul className="space-y-2">
              {category.skills.map((skill) => (
                <li key={skill.name} className="flex items-center text-slate-700 dark:text-slate-300">
                  {skill.icon && <span className="mr-3 text-sky-500 dark:text-sky-400 text-xl">{skill.icon}</span>}
                  <span>{skill.name}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default SkillsSection;
    