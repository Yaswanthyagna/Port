
import React from 'react';
import Section from './common/Section';

interface AboutSectionProps {
  id: string;
  profileContext: string;
}

const AboutSection: React.FC<AboutSectionProps> = ({ id, profileContext }) => {
  return (
    <Section id={id} title="About Me" className="bg-white dark:bg-slate-800">
      <div className="max-w-3xl mx-auto text-lg text-slate-700 dark:text-slate-300 space-y-6 leading-relaxed">
        {profileContext.split('\n\n').map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
    </Section>
  );
};

export default AboutSection;
    