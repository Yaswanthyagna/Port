
import React, { useState } from 'react';
import Section from './common/Section';
import Button from './common/Button';
import { DEVELOPER_PROFILE, IconMail, IconSocialGithub, IconSocialLinkedin } from '../constants';

interface ContactSectionProps {
  id: string;
}

const ContactSection: React.FC<ContactSectionProps> = ({ id }) => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Here you would typically send the form data to a backend service
    console.log("Form data submitted:", formData);
    setIsSubmitted(true);
    // Reset form after a delay for demo purposes
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  return (
    <Section id={id} title="Get In Touch" className="bg-slate-100 dark:bg-slate-900">
      <div className="max-w-3xl mx-auto grid md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <p className="text-lg text-slate-700 dark:text-slate-300">
            I'm always excited to discuss new projects, creative ideas, or opportunities to collaborate. 
            Feel free to reach out!
          </p>
          <div className="space-y-3">
            <a href={`mailto:${DEVELOPER_PROFILE.contact.email}`} className="flex items-center text-slate-700 dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
              <IconMail className="w-5 h-5 mr-3 text-sky-600 dark:text-sky-400" />
              {DEVELOPER_PROFILE.contact.email}
            </a>
            <a href={DEVELOPER_PROFILE.contact.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center text-slate-700 dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
              <IconSocialLinkedin className="w-5 h-5 mr-3 text-sky-600 dark:text-sky-400" />
              LinkedIn Profile
            </a>
            <a href={DEVELOPER_PROFILE.contact.github} target="_blank" rel="noopener noreferrer" className="flex items-center text-slate-700 dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400 transition-colors">
              <IconSocialGithub className="w-5 h-5 mr-3 text-sky-600 dark:text-sky-400" />
              GitHub Profile
            </a>
          </div>
        </div>

        <div>
          {isSubmitted ? (
            <div className="p-6 bg-green-50 dark:bg-green-900 border border-green-300 dark:border-green-700 rounded-lg text-center">
              <h3 className="text-xl font-semibold text-green-700 dark:text-green-300">Thank You!</h3>
              <p className="text-green-600 dark:text-green-400 mt-2">Your message has been sent (simulated). I'll get back to you soon.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Full Name</label>
                <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required
                       className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email Address</label>
                <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required
                       className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
                <textarea name="message" id="message" rows={4} value={formData.message} onChange={handleChange} required
                          className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"></textarea>
              </div>
              <div>
                <Button type="submit" variant="primary" className="w-full">Send Message</Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </Section>
  );
};

export default ContactSection;
    