
import React from 'react';

interface SectionProps {
  id: string;
  children: React.ReactNode;
  className?: string;
  title?: string;
}

const Section: React.FC<SectionProps> = ({ id, children, className = '', title }) => {
  return (
    <section 
      id={id} 
      className={`py-16 md:py-24 px-4 sm:px-6 lg:px-8 ${className}`}
    >
      <div className="max-w-5xl mx-auto">
        {title && (
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12 md:mb-16 text-slate-800 dark:text-slate-100">
            {title}
          </h2>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;
    