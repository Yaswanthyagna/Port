
import React from 'react';

// Fix: Updated ButtonProps to be a discriminated union for type safety with 'as' prop.
// Props common to both button and anchor styles
interface CommonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  className?: string;
}

// Specific props for <button> element + common styling props
type ButtonElementProps = CommonProps & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, keyof CommonProps> & {
  as?: 'button';
  href?: undefined; // Ensure href is not passed when it's a button
};

// Specific props for <a> element + common styling props
type AnchorElementProps = CommonProps & Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, keyof CommonProps> & {
  as: 'a';
  href: string; // href is required for an anchor
};

export type ButtonProps = ButtonElementProps | AnchorElementProps;

const Button: React.FC<ButtonProps> = (props) => {
  const {
    variant = 'primary',
    size = 'md',
    className = '', // Default for className
    leftIcon,
    rightIcon,
    children,
    // 'as' prop is used to discriminate and not passed down directly unless needed
    // 'href' is handled by the anchor specific props
  } = props;

  const baseStyles = "inline-flex items-center justify-center rounded-lg font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-900 transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed";
  const variantStyles = {
    primary: "bg-sky-600 hover:bg-sky-700 text-white focus:ring-sky-500",
    secondary: "bg-slate-600 hover:bg-slate-700 text-white focus:ring-slate-500",
    outline: "border border-sky-600 text-sky-600 dark:text-sky-400 dark:border-sky-400 hover:bg-sky-50 dark:hover:bg-sky-900 focus:ring-sky-500",
    ghost: "hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 focus:ring-slate-500",
  };
  const sizeStyles = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-5 py-2.5 text-base",
    lg: "px-7 py-3 text-lg",
  };

  const combinedClassName = `${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`;

  if (props.as === 'a') {
    // props is now AnchorElementProps
    // Destructure to remove CommonProps and 'as' before spreading the rest
    const { as: _as, children: _c, variant: _v, size: _s, leftIcon: _li, rightIcon: _ri, className: _cl, ...anchorSpecificProps } = props;
    return (
      <a className={combinedClassName} {...anchorSpecificProps}>
        {leftIcon && <span className="mr-2">{leftIcon}</span>}
        {children}
        {rightIcon && <span className="ml-2">{rightIcon}</span>}
      </a>
    );
  }

  // props is now ButtonElementProps (as is 'button' or undefined)
  // Destructure to remove CommonProps, 'as', and 'href' (which is undefined for buttons) before spreading the rest
  const { as: _as, children: _c, variant: _v, size: _s, leftIcon: _li, rightIcon: _ri, className: _cl, href: _h, ...buttonSpecificProps } = props;
  return (
    <button className={combinedClassName} {...buttonSpecificProps}>
      {leftIcon && <span className="mr-2">{leftIcon}</span>}
      {children}
      {rightIcon && <span className="ml-2">{rightIcon}</span>}
    </button>
  );
};

export default Button;
