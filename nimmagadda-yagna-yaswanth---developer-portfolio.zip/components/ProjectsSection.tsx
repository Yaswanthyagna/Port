
import React from 'react';
import Section from './common/Section';
import ProjectCard from './ProjectCard';
import { Project } from '../types';

interface ProjectsSectionProps {
  id: string;
  projects: Project[];
}

const ProjectsSection: React.FC<ProjectsSectionProps> = ({ id, projects }) => {
  return (
    <Section id={id} title="My Projects" className="bg-slate-100 dark:bg-slate-900">
      <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 md:gap-10">
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </Section>
  );
};

export default ProjectsSection;
    