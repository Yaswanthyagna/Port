
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChatMessage, DeveloperProfile } from '../types';
import { initializeChat, sendMessageToChatStream } from '../services/geminiService';
import { IconChatBubble, IconPaperAirplane, IconXMark } from '../constants';
import { Chat, GenerateContentResponse } from '@google/genai';

interface ChatbotFABProps {
  developerContext: DeveloperProfile;
}

const TypingIndicator: React.FC = () => (
  <div className="flex items-center space-x-1 p-2">
    <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
    <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
    <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce"></div>
  </div>
);

const ChatbotFAB: React.FC<ChatbotFABProps> = ({ developerContext }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chat, setChat] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize chat only if API key is potentially available.
    // The service itself handles the mock if key is missing.
    if (process.env.API_KEY || !process.env.API_KEY) { // This condition allows initialization even if key is missing, service handles it
        const chatInstance = initializeChat(developerContext);
        setChat(chatInstance);
        setMessages([
            { id: 'greeting', text: `Hello! I'm ${developerContext.name}'s AI assistant. How can I help you learn more about ${developerContext.name}?`, sender: 'ai', timestamp: new Date() }
        ]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [developerContext]); // Only re-init if developerContext changes significantly


  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSendMessage = useCallback(async () => {
    if (!inputValue.trim() || isLoading || !chat) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      let currentAiMessageId = Date.now().toString() + '-ai';
      setMessages(prev => [...prev, { id: currentAiMessageId, text: '', sender: 'ai', timestamp: new Date() }]);
      
      const stream = await sendMessageToChatStream(chat, userMessage.text);
      let fullResponse = '';
      for await (const chunk of stream) {
        const chunkText = chunk.text; // Access text directly from GenerateContentResponse
        if (chunkText) {
          fullResponse += chunkText;
          setMessages(prev => prev.map(m => 
            m.id === currentAiMessageId ? { ...m, text: fullResponse } : m
          ));
        }
      }
    } catch (error) {
      console.error("Chatbot error:", error);
      setMessages(prev => [...prev, { id: Date.now().toString() + '-error', text: "Sorry, I encountered an error. Please try again.", sender: 'ai', timestamp: new Date() }]);
    } finally {
      setIsLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inputValue, isLoading, chat]); // Add chat to dependency list

  if (!process.env.API_KEY && !chat) {
    // If API key is explicitly not set and chat couldn't initialize (even mock), don't render FAB.
    // This state might occur if initializeChat completely fails or returns null explicitly on no-key.
    // The current geminiService.ts returns a mock, so this path might not be hit often.
    return null; 
  }


  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 bg-sky-600 hover:bg-sky-700 text-white p-4 rounded-full shadow-xl transition-transform duration-200 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 dark:focus:ring-offset-slate-900 z-50"
        aria-label="Toggle Chatbot"
      >
        {isOpen ? <IconXMark className="w-7 h-7" /> : <IconChatBubble className="w-7 h-7" />}
      </button>

      {isOpen && (
        <div className="fixed bottom-20 right-6 w-full max-w-sm h-[70vh] max-h-[500px] bg-white dark:bg-slate-800 rounded-xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-slate-700 z-50">
          {/* Header */}
          <div className="p-4 bg-slate-100 dark:bg-slate-700 border-b border-slate-200 dark:border-slate-600">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Ask {developerContext.name.split(' ')[0]} Anything!</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Powered by Gemini</p>
          </div>

          {/* Messages Area */}
          <div className="flex-grow p-4 space-y-3 overflow-y-auto bg-slate-50 dark:bg-slate-800/50">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[80%] p-3 rounded-xl shadow ${
                    msg.sender === 'user'
                      ? 'bg-sky-500 text-white rounded-br-none'
                      : 'bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-bl-none'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{msg.text || (msg.sender === 'ai' && <TypingIndicator />)}</p>
                  <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-sky-200' : 'text-slate-500 dark:text-slate-400'} text-right`}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 border-t border-slate-200 dark:border-slate-600 bg-slate-100 dark:bg-slate-700">
            {isLoading && messages[messages.length-1]?.sender === 'ai' && messages[messages.length-1]?.text === '' && <TypingIndicator />}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center space-x-2"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Type your question..."
                className="flex-grow px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-500 rounded-lg focus:outline-none focus:ring-1 focus:ring-sky-500 text-sm text-slate-800 dark:text-slate-200"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className="p-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                aria-label="Send message"
              >
                <IconPaperAirplane className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatbotFAB;
    