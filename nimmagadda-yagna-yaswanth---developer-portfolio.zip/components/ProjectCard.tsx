
import React from 'react';
import { Project } from '../types';
import { IconExternalLink, IconSocialGithub } from '../constants';
import Button from './common/Button';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl flex flex-col">
      <img src={project.imageUrl} alt={project.title} className="w-full h-56 object-cover" />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-2xl font-semibold mb-2 text-slate-800 dark:text-slate-100">{project.title}</h3>
        <p className="text-slate-600 dark:text-slate-400 mb-4 text-sm flex-grow">{project.description}</p>
        <div className="mb-4">
          <h4 className="text-xs font-semibold uppercase text-slate-500 dark:text-slate-400 mb-1">Tech Stack:</h4>
          <div className="flex flex-wrap gap-2">
            {project.techStack.map((tech) => (
              <span key={tech} className="px-2 py-1 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 text-xs rounded-full">
                {tech}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-auto flex space-x-3 pt-4 border-t border-slate-200 dark:border-slate-700">
          {project.liveLink && (
            <Button 
              variant="outline" 
              size="sm" 
              as="a" 
              href={project.liveLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex-1"
              // Fix: Removed @ts-ignore as 'as' and 'download' props are now correctly handled by the polymorphic Button component.
              download={undefined} 
            >
                Live Demo <IconExternalLink className="ml-1.5 w-4 h-4" />
            </Button>
          )}
          {project.repoLink && (
            <Button 
              variant="ghost" 
              size="sm" 
              as="a" 
              href={project.repoLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex-1"
              // Fix: Removed @ts-ignore as 'as' and 'download' props are now correctly handled by the polymorphic Button component.
              download={undefined} 
            >
                View Code <IconSocialGithub className="ml-1.5 w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
