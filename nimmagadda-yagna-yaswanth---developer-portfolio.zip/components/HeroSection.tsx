
import React from 'react';
import Section from './common/Section';
import Button from './common/Button';
import { DEVELOPER_PROFILE, SECTION_IDS } from '../constants';

interface HeroSectionProps {
  id: string;
}

const HeroSection: React.FC<HeroSectionProps> = ({ id }) => {
  return (
    <Section id={id} className="bg-gradient-to-br from-sky-100 via-slate-50 to-indigo-100 dark:from-slate-800 dark:via-slate-900 dark:to-indigo-900 min-h-screen flex items-center !pt-16">
      <div className="text-center mx-auto max-w-3xl">
        <img 
          src={DEVELOPER_PROFILE.profilePictureUrl} 
          alt={DEVELOPER_PROFILE.name}
          className="w-40 h-40 md:w-48 md:h-48 rounded-full mx-auto mb-8 shadow-xl border-4 border-white dark:border-slate-700"
        />
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 dark:text-slate-50 mb-4">
          Hi, I'm <span className="text-sky-600 dark:text-sky-400">{DEVELOPER_PROFILE.name}</span>
        </h1>
        <p className="text-xl sm:text-2xl text-slate-700 dark:text-slate-300 mb-8">
          {DEVELOPER_PROFILE.tagline}
        </p>
        <div className="space-x-4">
          <Button variant="primary" size="lg" onClick={() => document.getElementById(SECTION_IDS.projects)?.scrollIntoView({ behavior: 'smooth' })}>
            View My Work
          </Button>
          <Button variant="outline" size="lg" onClick={() => document.getElementById(SECTION_IDS.contact)?.scrollIntoView({ behavior: 'smooth' })}>
            Get In Touch
          </Button>
        </div>
      </div>
    </Section>
  );
};

export default HeroSection;
    