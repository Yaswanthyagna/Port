
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { DeveloperProfile } from '../types';

// Ensure API_KEY is handled by the environment, DO NOT ADD UI FOR IT.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API Key not found. Chatbot functionality will be limited. Ensure process.env.API_KEY is set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Exclamation mark assumes API_KEY will be there

const model = 'gemini-2.5-flash-preview-04-17';

// Simplified context string for the chatbot
const generateSystemPrompt = (profile: DeveloperProfile): string => {
  let projectSummaries = profile.projects.map(p => `- ${p.title}: ${p.description.substring(0,100)}...`).join("\n");
  let skillSummary = profile.skills.map(cat => `${cat.name}: ${cat.skills.map(s => s.name).join(', ')}`).join("\n");

  return `You are a friendly and helpful AI assistant representing ${profile.name}, a ${profile.tagline}.
Your goal is to answer questions about ${profile.name}'s skills, experience, and projects based on the following context.
Keep your answers concise, professional, and engaging.
If a question is unrelated to ${profile.name}'s professional profile, politely state that you can only answer questions about ${profile.name}.
Do not make up information not present in the context.

Context:
Name: ${profile.name}
Tagline: ${profile.tagline}

About ${profile.name}:
${profile.about}

Skills:
${skillSummary}

Projects:
${projectSummaries}

You can also talk generally about software development, AI, and UI/UX topics if relevant to ${profile.name}'s profile.
Be conversational and try to provide helpful insights.
`;
};


let chatInstance: Chat | null = null;

export const initializeChat = (profile: DeveloperProfile): Chat => {
  if (!API_KEY) {
    // Return a mock chat instance if API key is not available
    // This allows the UI to function without crashing.
    console.error("API Key for Gemini is not configured. Chatbot will not connect to AI.");
    return {
      sendMessage: async () => ({ text: "I am currently unable to connect to the AI service. Please ensure the API key is configured." } as GenerateContentResponse),
      sendMessageStream: async function*() {
        yield { text: "I am currently unable to connect to the AI service. " } as GenerateContentResponse;
        yield { text: "Please ensure the API key is configured." } as GenerateContentResponse;
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any as Chat; // Type assertion for mock chat
  }

  if (!chatInstance) {
     chatInstance = ai.chats.create({
        model: model,
        config: {
          systemInstruction: generateSystemPrompt(profile),
          // For conversational AI, default thinking budget is usually fine.
          // thinkingConfig: { thinkingBudget: 0 } // if very low latency needed and willing to sacrifice some quality
        },
      });
  }
  return chatInstance;
};

export const sendMessageToChatStream = async (
  chat: Chat,
  message: string
): Promise<AsyncGenerator<GenerateContentResponse, void, undefined>> => {
  if (!API_KEY && chat.sendMessageStream.toString().includes("API key is not configured")) { // Check if it's the mock
    return (async function*() {
        yield { text: "I am currently unable to connect to the AI service. " } as GenerateContentResponse;
        yield { text: "Please ensure the API key is configured." } as GenerateContentResponse;
      })();
  }
  try {
    const result = await chat.sendMessageStream({ message });
    return result;
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    throw error; // Re-throw to be handled by the caller
  }
};
    